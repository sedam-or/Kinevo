# Kinevo — Scheduling Engine Contract

> STATUS: AUTHORITATIVE (P29 2026-08-31). Canonical deterministic scheduling
> authority (ADR-015 effective schedule + ADR-016 draft lifecycle). Domain
> meaning: `docs/domain-model.md` §3.5.

### Mission
Generate safe, explainable, deterministic schedules and reschedule proposals while preserving user-controlled constraints.

### Scheduler modes
- `AUTO_DRAFT`: generate draft only.
- `RESCHEDULE_PROPOSAL`: generate diff, wait for confirmation.
- `MANUAL_ASSIST`: answer slot/capacity queries.
- `SIMULATION`: no mutation; used in tests/analysis.

### Core algorithm
```text
1. Acquire scheduler run lock.
2. Snapshot relevant state.
3. Normalize timezone and temporal intervals.
4. Build Hard Landscape intervals.
5. Build occupied intervals.
6. Calculate Dynamic Empty Slots.
7. Place Sacred Anchor.
8. Build task candidate set.
9. Apply hard constraints.
10. Rank candidates.
11. Score soft signals.
12. Assign candidate tasks.
13. Validate schedule.
14. Calculate overload/capacity.
15. Produce explanations.
16. Persist draft/version.
17. Release lock.
```

### Hard constraint ordering
1. No Hard Landscape collision.
2. Do not move locked task through automation.
3. Sacred Anchor rule.
4. Temporal validity.
5. Deadline feasibility.
6. Valid duration and slot fit.
7. No illegal overlap.
8. Safety reserve.
9. No automatic task deletion.

### Soft ranking
Recommended lexicographic ordering:
1. priority tier;
2. nearest goal deadline;
3. milestone urgency;
4. task deadline;
5. progress leverage;
6. context fit;
7. fragmentation penalty;
8. duration fit;
9. continuity preference.

### Soft scoring examples
Do not make one giant opaque score. Prefer independently testable components:
- `priority_score`;
- `deadline_score`;
- `milestone_score`;
- `capacity_fit_score`;
- `context_fit_score`;
- `progress_value_score`;
- `fragmentation_penalty`.

The final candidate ordering MAY combine them, but each component MUST remain observable in explanation/debug output.

### Explainability contract
Each generated assignment SHOULD include:
- candidate reason;
- accepted constraints;
- rejected alternatives where useful;
- primary priority;
- deadline pressure;
- capacity context;
- soft context signal used.

Example:
```json
{
  "decision": "ASSIGN",
  "task_id": "uuid",
  "slot": "2026-08-19T09:00:00+07:00/2026-08-19T09:45:00+07:00",
  "reason_codes": [
    "DEADLINE_NEAR",
    "SLOT_FIT_EXACT",
    "HIGH_PRIORITY"
  ]
}
```

### Dynamic Empty Slot contract
A Dynamic Empty Slot is an interval `[start,end)` with duration >= 15 minutes and free from prohibited overlap.

### Schedule versioning
Every meaningful schedule mutation MUST have a schedule version. Applying a stale schedule proposal MUST return `409 SCHEDULE_VERSION_CONFLICT`.

### Draft versus applied schedule
Auto-scheduler output is not authoritative until explicit application when the mode requires confirmation.

### Failure behavior
If no valid solution exists:
- do not delete task;
- retain task;
- create conflict marker;
- return actionable alternatives.

### Simulation test matrix
At minimum test:
- zero hard landscape;
- adjacent hard landscape blocks;
- gap exactly 15 minutes;
- gap 14 minutes;
- Sacred Anchor placement;
- locked task;
- multiple equal-priority tasks;
- deadline tie;
- no available solution;
- Emergency Pause;
- Break Mode;
- low effective capacity;
- concurrent mutation.

---

## Effective Schedule Resolution (ADR-015, implemented 2026-08-30)

The scheduling views, the draft generator, the rescheduler, and ICS export consume the
**Effective Landscape Resolver** (`App\Domain\Scheduling\Resolution\EffectiveLandscapeResolver`)
— one canonical resolution pipeline:

```
source event → recurrence expansion → base occurrence → override resolution → effective occurrence
```

- Recurrence semantics remain owned exclusively by `RecurrenceRule` +
  `RecurrenceOccurrenceGenerator` (DAILY/WEEKLY, INTERVAL, BYDAY, COUNT/UNTIL).
  **UNTIL is enforced by the generator** (ES-FIX-00): inclusive — a date-only UNTIL includes
  its local date, a datetime UNTIL includes its instant, a trailing `Z` is UTC normalized to
  the DTSTART timezone; COUNT + UNTIL → whichever terminates first. COUNT counts from
  DTSTART (series start), not from the query window.
- Override precedence inside one series: ONE-TIME EXCEPTION > LATEST APPLICABLE PERMANENT
  SHIFT (greatest `effective_from`, tie-break greatest id) > BASE RECURRENCE. A covered
  occurrence is re-timed by the date delta between its original date and the shift's
  `effective_from`, keeping the override interval's time-of-day and duration. A cancelling
  one-time exception (`cancels_occurrence`) removes exactly its target occurrence.
- Read models filter by the EFFECTIVE window: a shifted occurrence appears on its effective
  date and is vacated from its original date.
- History: superseded/deleted assignments are archived into `schedule_assignment_history`
  in the same transaction as the live mutation (draft apply, reschedule apply, auto-swap,
  pause paths), plus `schedule_draft_applied` / `schedule_reschedule_applied` /
  `schedule_override_applied` / `assignment_locked` / `assignment_unlocked` activity events.
- Locked placements: produced only by the user via
  `POST /tasks/{taskId}/assignment/lock|unlock`; the scheduler and rescheduler receive
  `isLocked` input and never move them (existing hard-rule + apply-conflict contracts
  unchanged). AI has no path into schedule authority.
## Scheduler Trigger, Sync Now & Draft Lifecycle (ADR-016, implemented 2026-08-31)

**Weekly trigger.** `schedule:prepare-weekly` (daily 04:00 UTC pass,
`withoutOverlapping`) prepares a persisted pending planning draft for each user
whose LOCAL date is Monday (profile timezone decides the week). Horizon: local
Monday–Sunday. Idempotent per `(user, weekly, week anchor)` — one row per
user/week ever; duplicate runs skip; a stale pending draft is refreshed in
place; an applied/discarded week is never regenerated. No schedulable work →
no draft, no notification. The draft proposes placement of unscheduled flexible
work into effective free slots (Sacred Anchor first when present); it NEVER
auto-applies. `weekly_draft_ready` notification, deduped per week anchor.

**Sync Now.** `POST /schedule/sync` returns `no_changes` / `proposal` /
`run_in_progress` — the SAME deterministic rescheduler diff over the current
Effective Landscape (ADR-015), read-only, bounded horizon (≤ 14 days or the
profile-local week). Apply stays the explicit reschedule-apply endpoint (409
on stale base). `no_changes` acknowledges the review state.

**Reality-change trigger.** Hard Landscape create/update/delete, KRS/ICS
import confirm, and Schedule Override create/update/delete run a bounded,
failure-isolated post-commit impact check: accepted auto-sourced placements
(draft/reschedule/quick_capture) overlapping effective occurrences within
[today−7, today+14] (local) → `schedule_states.needs_review = true` +
`schedule_needs_review` attention notification (false→true transition, deduped
per local day). Read payloads (Today/Week/Month/range) expose
`schedule_needs_review`. Never auto-applies; outside-window changes trigger
nothing; a mutation never fails because impact detection failed.

**Run lock.** `Cache::lock('schedule:sync:{userId}' | 'schedule:weekly:{userId}')`
(database lock store, TTL 60 s, non-blocking) guards computation. Apply is NOT
lock-guarded — the optimistic `base_version`/409 semantics remain the single
write-concurrency authority. Lock contention: Sync Now → `run_in_progress`;
weekly pass → skip (next day retries).

**Draft lifecycle.** Weekly drafts persist in `schedule_drafts`
(pending → applied | discarded | superseded); manual drafts remain ephemeral
client-held JSON. Staleness is derived (base_version ≠ current version).
Applying with `draft_id` closes the draft and acknowledges review state.
Discard never mutates accepted placements.

**Run lock telemetry.** Weekly prepare and Sync Now record `scheduler_runs`
(`schedule:prepare-weekly`, `schedule:sync`).

**Sacred Anchor producer.** `tasks.is_sacred_anchor` (at most one per user,
validated on create/update) feeds the generator's anchor placement (25 min,
first qualifying slot at/after 06:00 — a slot starting before 06:00 that
contains 06:00 qualifies with the anchor clipped to 06:00). FR-04 XP/study
modes/multi-track remain deferred.
