--
-- PostgreSQL database dump
--

\restrict yeet7BX3hvARiL1kAzhzlvXb0m2ZrnWUqy51fTSGITa37c23xiZt54MEXjb00vF

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: notes_search_trigger(); Type: FUNCTION; Schema: public; Owner: kinevo
--

CREATE FUNCTION public.notes_search_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.search_vector := to_tsvector('english', COALESCE(NEW.title, '') || ' ' || COALESCE(NEW.plain_text_cache, ''));
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.notes_search_trigger() OWNER TO kinevo;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.activity_logs (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    event_type character varying(30) NOT NULL,
    entity_type character varying(20) NOT NULL,
    entity_id bigint NOT NULL,
    title character varying(200),
    event_at timestamp(0) without time zone NOT NULL,
    operation_id character varying(64),
    payload json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.activity_logs OWNER TO kinevo;

--
-- Name: activity_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.activity_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.activity_logs_id_seq OWNER TO kinevo;

--
-- Name: activity_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.activity_logs_id_seq OWNED BY public.activity_logs.id;


--
-- Name: adaptive_context; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.adaptive_context (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    task_id bigint,
    energy_level smallint,
    stress_level smallint,
    task_difficulty smallint,
    skill_familiarity smallint,
    interruption_count smallint,
    context_switch_cost smallint,
    focus_duration_minutes integer,
    checked_at timestamp(0) without time zone NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.adaptive_context OWNER TO kinevo;

--
-- Name: adaptive_context_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.adaptive_context_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.adaptive_context_id_seq OWNER TO kinevo;

--
-- Name: adaptive_context_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.adaptive_context_id_seq OWNED BY public.adaptive_context.id;


--
-- Name: ai_proposals; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.ai_proposals (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    proposal_type character varying(40) NOT NULL,
    schema_version smallint NOT NULL,
    payload json NOT NULL,
    validation_result character varying(20) DEFAULT 'valid'::character varying NOT NULL,
    decision character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    operation_id character varying(64),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.ai_proposals OWNER TO kinevo;

--
-- Name: ai_proposals_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.ai_proposals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_proposals_id_seq OWNER TO kinevo;

--
-- Name: ai_proposals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.ai_proposals_id_seq OWNED BY public.ai_proposals.id;


--
-- Name: ai_provider_configs; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.ai_provider_configs (
    id bigint NOT NULL,
    provider character varying(32) DEFAULT 'disabled'::character varying NOT NULL,
    model character varying(128),
    base_url character varying(255),
    api_key text,
    enabled boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    user_id bigint,
    protocol character varying(32),
    credential_hint character varying(64),
    last_verified_at timestamp(0) without time zone,
    last_status character varying(32),
    last_error_code character varying(64)
);


ALTER TABLE public.ai_provider_configs OWNER TO kinevo;

--
-- Name: ai_provider_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.ai_provider_configs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_provider_configs_id_seq OWNER TO kinevo;

--
-- Name: ai_provider_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.ai_provider_configs_id_seq OWNED BY public.ai_provider_configs.id;


--
-- Name: ai_runs; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.ai_runs (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    provider character varying(30) NOT NULL,
    model character varying(120) NOT NULL,
    proposal_type character varying(40) NOT NULL,
    schema_version smallint,
    prompt_template_version character varying(20),
    context_hash character varying(64),
    input_tokens integer,
    output_tokens integer,
    status character varying(20) NOT NULL,
    latency_ms integer DEFAULT 0 NOT NULL,
    error_code character varying(40),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.ai_runs OWNER TO kinevo;

--
-- Name: ai_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.ai_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_runs_id_seq OWNER TO kinevo;

--
-- Name: ai_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.ai_runs_id_seq OWNED BY public.ai_runs.id;


--
-- Name: attachments; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.attachments (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    task_id bigint NOT NULL,
    filename character varying(255) NOT NULL,
    stored_name character varying(255) NOT NULL,
    disk character varying(32) DEFAULT 'local'::character varying NOT NULL,
    mime_type character varying(64) NOT NULL,
    size_bytes bigint NOT NULL,
    sha256 character(64) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.attachments OWNER TO kinevo;

--
-- Name: attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.attachments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attachments_id_seq OWNER TO kinevo;

--
-- Name: attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.attachments_id_seq OWNED BY public.attachments.id;


--
-- Name: boost_targets; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.boost_targets (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    break_period_id bigint,
    start_date date NOT NULL,
    end_date date NOT NULL,
    target_percent smallint NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.boost_targets OWNER TO kinevo;

--
-- Name: boost_targets_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.boost_targets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.boost_targets_id_seq OWNER TO kinevo;

--
-- Name: boost_targets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.boost_targets_id_seq OWNED BY public.boost_targets.id;


--
-- Name: break_periods; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.break_periods (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.break_periods OWNER TO kinevo;

--
-- Name: break_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.break_periods_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.break_periods_id_seq OWNER TO kinevo;

--
-- Name: break_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.break_periods_id_seq OWNED BY public.break_periods.id;


--
-- Name: cache; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.cache (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    expiration bigint NOT NULL
);


ALTER TABLE public.cache OWNER TO kinevo;

--
-- Name: cache_locks; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.cache_locks (
    key character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    expiration bigint NOT NULL
);


ALTER TABLE public.cache_locks OWNER TO kinevo;

--
-- Name: canvas_documents; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.canvas_documents (
    id bigint NOT NULL,
    canvas_id bigint NOT NULL,
    schema_version integer DEFAULT 1 NOT NULL,
    scene_json jsonb NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.canvas_documents OWNER TO kinevo;

--
-- Name: canvas_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.canvas_documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.canvas_documents_id_seq OWNER TO kinevo;

--
-- Name: canvas_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.canvas_documents_id_seq OWNED BY public.canvas_documents.id;


--
-- Name: canvas_files; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.canvas_files (
    id bigint NOT NULL,
    canvas_id bigint NOT NULL,
    storage_path character varying(255) NOT NULL,
    content_type character varying(255) NOT NULL,
    size_bytes bigint NOT NULL,
    sha256 character varying(64),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.canvas_files OWNER TO kinevo;

--
-- Name: canvas_files_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.canvas_files_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.canvas_files_id_seq OWNER TO kinevo;

--
-- Name: canvas_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.canvas_files_id_seq OWNED BY public.canvas_files.id;


--
-- Name: canvases; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.canvases (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    title character varying(255) NOT NULL,
    goal_id bigint,
    milestone_id bigint,
    program_id bigint,
    task_id bigint,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    archived_at timestamp(0) without time zone,
    workspace_id bigint
);


ALTER TABLE public.canvases OWNER TO kinevo;

--
-- Name: canvases_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.canvases_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.canvases_id_seq OWNER TO kinevo;

--
-- Name: canvases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.canvases_id_seq OWNED BY public.canvases.id;


--
-- Name: execution_sessions; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.execution_sessions (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    task_id bigint NOT NULL,
    status character varying(20) NOT NULL,
    started_at timestamp(0) without time zone NOT NULL,
    last_resumed_at timestamp(0) without time zone,
    accumulated_seconds integer DEFAULT 0 NOT NULL,
    ended_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.execution_sessions OWNER TO kinevo;

--
-- Name: execution_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.execution_sessions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.execution_sessions_id_seq OWNER TO kinevo;

--
-- Name: execution_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.execution_sessions_id_seq OWNED BY public.execution_sessions.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection character varying(255) NOT NULL,
    queue character varying(255) NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO kinevo;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.failed_jobs_id_seq OWNER TO kinevo;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: focus_sessions; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.focus_sessions (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    task_id bigint,
    started_at timestamp(0) without time zone NOT NULL,
    ended_at timestamp(0) without time zone NOT NULL,
    duration_minutes integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.focus_sessions OWNER TO kinevo;

--
-- Name: focus_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.focus_sessions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.focus_sessions_id_seq OWNER TO kinevo;

--
-- Name: focus_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.focus_sessions_id_seq OWNED BY public.focus_sessions.id;


--
-- Name: goals; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.goals (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    title character varying(200) NOT NULL,
    description text,
    horizon character varying(20) NOT NULL,
    start_date date,
    target_date date,
    target_metric character varying(100),
    status character varying(20) DEFAULT 'draft'::character varying NOT NULL,
    priority_tier smallint DEFAULT '3'::smallint NOT NULL,
    progress_mode character varying(20) DEFAULT 'derived'::character varying NOT NULL,
    progress smallint DEFAULT '0'::smallint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    workspace_id bigint
);


ALTER TABLE public.goals OWNER TO kinevo;

--
-- Name: goals_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.goals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.goals_id_seq OWNER TO kinevo;

--
-- Name: goals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.goals_id_seq OWNED BY public.goals.id;


--
-- Name: hard_landscape_events; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.hard_landscape_events (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    title character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    start_at timestamp(0) without time zone NOT NULL,
    end_at timestamp(0) without time zone NOT NULL,
    recurrence character varying(500),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.hard_landscape_events OWNER TO kinevo;

--
-- Name: hard_landscape_events_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.hard_landscape_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.hard_landscape_events_id_seq OWNER TO kinevo;

--
-- Name: hard_landscape_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.hard_landscape_events_id_seq OWNED BY public.hard_landscape_events.id;


--
-- Name: imports; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.imports (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    type character varying(32) DEFAULT 'krs_pdf'::character varying NOT NULL,
    filename character varying(255) NOT NULL,
    status character varying(16) DEFAULT 'pending'::character varying NOT NULL,
    confidence double precision,
    rows json NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.imports OWNER TO kinevo;

--
-- Name: imports_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.imports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.imports_id_seq OWNER TO kinevo;

--
-- Name: imports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.imports_id_seq OWNED BY public.imports.id;


--
-- Name: job_batches; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.job_batches (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    total_jobs integer NOT NULL,
    pending_jobs integer NOT NULL,
    failed_jobs integer NOT NULL,
    failed_job_ids text NOT NULL,
    options text,
    cancelled_at integer,
    created_at integer NOT NULL,
    finished_at integer
);


ALTER TABLE public.job_batches OWNER TO kinevo;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.jobs (
    id bigint NOT NULL,
    queue character varying(255) NOT NULL,
    payload text NOT NULL,
    attempts smallint NOT NULL,
    reserved_at integer,
    available_at integer NOT NULL,
    created_at integer NOT NULL
);


ALTER TABLE public.jobs OWNER TO kinevo;

--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.jobs_id_seq OWNER TO kinevo;

--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: knowledge_links; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.knowledge_links (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    source_type character varying(30) NOT NULL,
    source_id bigint NOT NULL,
    target_type character varying(30) NOT NULL,
    target_id bigint NOT NULL,
    link_type character varying(30) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.knowledge_links OWNER TO kinevo;

--
-- Name: knowledge_links_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.knowledge_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.knowledge_links_id_seq OWNER TO kinevo;

--
-- Name: knowledge_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.knowledge_links_id_seq OWNED BY public.knowledge_links.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO kinevo;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migrations_id_seq OWNER TO kinevo;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: milestones; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.milestones (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    goal_id bigint NOT NULL,
    title character varying(200) NOT NULL,
    description text,
    sequence integer DEFAULT 0 NOT NULL,
    target_date date,
    estimated_minutes integer,
    status character varying(20) DEFAULT 'planned'::character varying NOT NULL,
    progress_mode character varying(20) DEFAULT 'derived'::character varying NOT NULL,
    progress smallint DEFAULT '0'::smallint NOT NULL,
    completed_at timestamp(0) without time zone,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.milestones OWNER TO kinevo;

--
-- Name: milestones_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.milestones_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.milestones_id_seq OWNER TO kinevo;

--
-- Name: milestones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.milestones_id_seq OWNED BY public.milestones.id;


--
-- Name: notes; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.notes (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    title character varying(255) NOT NULL,
    document_json json,
    markdown_cache text,
    plain_text_cache text,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    search_vector tsvector,
    workspace_id bigint
);


ALTER TABLE public.notes OWNER TO kinevo;

--
-- Name: notes_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.notes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notes_id_seq OWNER TO kinevo;

--
-- Name: notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.notes_id_seq OWNED BY public.notes.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.notifications (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    type character varying(30) NOT NULL,
    scheduled_for date,
    title character varying(200),
    payload json,
    read_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.notifications OWNER TO kinevo;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO kinevo;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO kinevo;

--
-- Name: pause_events; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.pause_events (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    type character varying(20) NOT NULL,
    week_start date NOT NULL,
    week_end date NOT NULL,
    keep_task_ids json,
    moved_task_ids json,
    conflict_task_ids json,
    schedule_version bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.pause_events OWNER TO kinevo;

--
-- Name: pause_events_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.pause_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pause_events_id_seq OWNER TO kinevo;

--
-- Name: pause_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.pause_events_id_seq OWNED BY public.pause_events.id;


--
-- Name: personal_access_tokens; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.personal_access_tokens (
    id bigint NOT NULL,
    tokenable_type character varying(255) NOT NULL,
    tokenable_id bigint NOT NULL,
    name text NOT NULL,
    token character varying(64) NOT NULL,
    abilities text,
    last_used_at timestamp(0) without time zone,
    expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.personal_access_tokens OWNER TO kinevo;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.personal_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.personal_access_tokens_id_seq OWNER TO kinevo;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.personal_access_tokens_id_seq OWNED BY public.personal_access_tokens.id;


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.profiles (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    display_name character varying(255),
    locale character varying(10) DEFAULT 'en'::character varying NOT NULL,
    timezone character varying(64) DEFAULT 'UTC'::character varying NOT NULL,
    week_start_day character varying(9) DEFAULT 'monday'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.profiles OWNER TO kinevo;

--
-- Name: profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.profiles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.profiles_id_seq OWNER TO kinevo;

--
-- Name: profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.profiles_id_seq OWNED BY public.profiles.id;


--
-- Name: programs; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.programs (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    category character varying(100),
    workload_type character varying(20) NOT NULL,
    weekly_target_minutes integer,
    min_weekly_minutes integer,
    max_weekly_minutes integer,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    priority_tier smallint DEFAULT '3'::smallint NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    workspace_id bigint
);


ALTER TABLE public.programs OWNER TO kinevo;

--
-- Name: programs_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.programs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.programs_id_seq OWNER TO kinevo;

--
-- Name: programs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.programs_id_seq OWNED BY public.programs.id;


--
-- Name: progress_events; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.progress_events (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    event_type character varying(30) NOT NULL,
    entity_type character varying(20) NOT NULL,
    entity_id bigint NOT NULL,
    title character varying(200),
    occurred_at timestamp(0) without time zone NOT NULL,
    operation_id character varying(64),
    payload json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.progress_events OWNER TO kinevo;

--
-- Name: progress_events_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.progress_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.progress_events_id_seq OWNER TO kinevo;

--
-- Name: progress_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.progress_events_id_seq OWNED BY public.progress_events.id;


--
-- Name: recharge_sessions; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.recharge_sessions (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    status character varying(255) NOT NULL,
    started_at timestamp(0) without time zone NOT NULL,
    last_resumed_at timestamp(0) without time zone,
    accumulated_seconds integer DEFAULT 0 NOT NULL,
    duration_minutes integer,
    ended_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.recharge_sessions OWNER TO kinevo;

--
-- Name: recharge_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.recharge_sessions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recharge_sessions_id_seq OWNER TO kinevo;

--
-- Name: recharge_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.recharge_sessions_id_seq OWNED BY public.recharge_sessions.id;


--
-- Name: schedule_overrides; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.schedule_overrides (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    hard_landscape_event_id bigint NOT NULL,
    type character varying(20) NOT NULL,
    effective_from timestamp(0) without time zone NOT NULL,
    effective_to timestamp(0) without time zone NOT NULL,
    override_start_at timestamp(0) without time zone NOT NULL,
    override_end_at timestamp(0) without time zone NOT NULL,
    reason character varying(500),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.schedule_overrides OWNER TO kinevo;

--
-- Name: schedule_overrides_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.schedule_overrides_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.schedule_overrides_id_seq OWNER TO kinevo;

--
-- Name: schedule_overrides_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.schedule_overrides_id_seq OWNED BY public.schedule_overrides.id;


--
-- Name: scheduler_runs; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.scheduler_runs (
    id bigint NOT NULL,
    user_id bigint,
    job character varying(60) NOT NULL,
    status character varying(20) NOT NULL,
    duration_ms integer DEFAULT 0 NOT NULL,
    error character varying(255),
    started_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.scheduler_runs OWNER TO kinevo;

--
-- Name: scheduler_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.scheduler_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.scheduler_runs_id_seq OWNER TO kinevo;

--
-- Name: scheduler_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.scheduler_runs_id_seq OWNED BY public.scheduler_runs.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


ALTER TABLE public.sessions OWNER TO kinevo;

--
-- Name: subtasks; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.subtasks (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    task_id bigint NOT NULL,
    title character varying(200) NOT NULL,
    notes text,
    sequence integer DEFAULT 0 NOT NULL,
    completed boolean DEFAULT false NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.subtasks OWNER TO kinevo;

--
-- Name: subtasks_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.subtasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.subtasks_id_seq OWNER TO kinevo;

--
-- Name: subtasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.subtasks_id_seq OWNED BY public.subtasks.id;


--
-- Name: task_assignments; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.task_assignments (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    task_id bigint NOT NULL,
    date date NOT NULL,
    start_at timestamp(0) without time zone NOT NULL,
    end_at timestamp(0) without time zone NOT NULL,
    duration_minutes integer NOT NULL,
    status character varying(50) NOT NULL,
    source character varying(50) NOT NULL,
    schedule_version integer DEFAULT 1 NOT NULL,
    locked boolean DEFAULT false NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.task_assignments OWNER TO kinevo;

--
-- Name: task_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.task_assignments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_assignments_id_seq OWNER TO kinevo;

--
-- Name: task_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.task_assignments_id_seq OWNED BY public.task_assignments.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.tasks (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    program_id bigint,
    goal_id bigint,
    milestone_id bigint,
    title character varying(200) NOT NULL,
    description text,
    status character varying(20) DEFAULT 'backlog'::character varying NOT NULL,
    priority_tier smallint DEFAULT '3'::smallint NOT NULL,
    estimated_minutes integer,
    due_at timestamp(0) without time zone,
    progress_mode character varying(20) DEFAULT 'derived'::character varying NOT NULL,
    progress smallint DEFAULT '0'::smallint NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    workspace_id bigint
);


ALTER TABLE public.tasks OWNER TO kinevo;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tasks_id_seq OWNER TO kinevo;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.users OWNER TO kinevo;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO kinevo;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: workspaces; Type: TABLE; Schema: public; Owner: kinevo
--

CREATE TABLE public.workspaces (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    name character varying(80) NOT NULL,
    slug character varying(80) NOT NULL,
    description character varying(500),
    icon character varying(32),
    accent character varying(16),
    type character varying(20) DEFAULT 'personal'::character varying NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.workspaces OWNER TO kinevo;

--
-- Name: workspaces_id_seq; Type: SEQUENCE; Schema: public; Owner: kinevo
--

CREATE SEQUENCE public.workspaces_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.workspaces_id_seq OWNER TO kinevo;

--
-- Name: workspaces_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kinevo
--

ALTER SEQUENCE public.workspaces_id_seq OWNED BY public.workspaces.id;


--
-- Name: activity_logs id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.activity_logs ALTER COLUMN id SET DEFAULT nextval('public.activity_logs_id_seq'::regclass);


--
-- Name: adaptive_context id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.adaptive_context ALTER COLUMN id SET DEFAULT nextval('public.adaptive_context_id_seq'::regclass);


--
-- Name: ai_proposals id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.ai_proposals ALTER COLUMN id SET DEFAULT nextval('public.ai_proposals_id_seq'::regclass);


--
-- Name: ai_provider_configs id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.ai_provider_configs ALTER COLUMN id SET DEFAULT nextval('public.ai_provider_configs_id_seq'::regclass);


--
-- Name: ai_runs id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.ai_runs ALTER COLUMN id SET DEFAULT nextval('public.ai_runs_id_seq'::regclass);


--
-- Name: attachments id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.attachments ALTER COLUMN id SET DEFAULT nextval('public.attachments_id_seq'::regclass);


--
-- Name: boost_targets id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.boost_targets ALTER COLUMN id SET DEFAULT nextval('public.boost_targets_id_seq'::regclass);


--
-- Name: break_periods id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.break_periods ALTER COLUMN id SET DEFAULT nextval('public.break_periods_id_seq'::regclass);


--
-- Name: canvas_documents id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.canvas_documents ALTER COLUMN id SET DEFAULT nextval('public.canvas_documents_id_seq'::regclass);


--
-- Name: canvas_files id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.canvas_files ALTER COLUMN id SET DEFAULT nextval('public.canvas_files_id_seq'::regclass);


--
-- Name: canvases id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.canvases ALTER COLUMN id SET DEFAULT nextval('public.canvases_id_seq'::regclass);


--
-- Name: execution_sessions id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.execution_sessions ALTER COLUMN id SET DEFAULT nextval('public.execution_sessions_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: focus_sessions id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.focus_sessions ALTER COLUMN id SET DEFAULT nextval('public.focus_sessions_id_seq'::regclass);


--
-- Name: goals id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.goals ALTER COLUMN id SET DEFAULT nextval('public.goals_id_seq'::regclass);


--
-- Name: hard_landscape_events id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.hard_landscape_events ALTER COLUMN id SET DEFAULT nextval('public.hard_landscape_events_id_seq'::regclass);


--
-- Name: imports id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.imports ALTER COLUMN id SET DEFAULT nextval('public.imports_id_seq'::regclass);


--
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Name: knowledge_links id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.knowledge_links ALTER COLUMN id SET DEFAULT nextval('public.knowledge_links_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: milestones id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.milestones ALTER COLUMN id SET DEFAULT nextval('public.milestones_id_seq'::regclass);


--
-- Name: notes id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.notes ALTER COLUMN id SET DEFAULT nextval('public.notes_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: pause_events id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.pause_events ALTER COLUMN id SET DEFAULT nextval('public.pause_events_id_seq'::regclass);


--
-- Name: personal_access_tokens id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.personal_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.personal_access_tokens_id_seq'::regclass);


--
-- Name: profiles id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.profiles ALTER COLUMN id SET DEFAULT nextval('public.profiles_id_seq'::regclass);


--
-- Name: programs id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.programs ALTER COLUMN id SET DEFAULT nextval('public.programs_id_seq'::regclass);


--
-- Name: progress_events id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.progress_events ALTER COLUMN id SET DEFAULT nextval('public.progress_events_id_seq'::regclass);


--
-- Name: recharge_sessions id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.recharge_sessions ALTER COLUMN id SET DEFAULT nextval('public.recharge_sessions_id_seq'::regclass);


--
-- Name: schedule_overrides id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.schedule_overrides ALTER COLUMN id SET DEFAULT nextval('public.schedule_overrides_id_seq'::regclass);


--
-- Name: scheduler_runs id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.scheduler_runs ALTER COLUMN id SET DEFAULT nextval('public.scheduler_runs_id_seq'::regclass);


--
-- Name: subtasks id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.subtasks ALTER COLUMN id SET DEFAULT nextval('public.subtasks_id_seq'::regclass);


--
-- Name: task_assignments id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.task_assignments ALTER COLUMN id SET DEFAULT nextval('public.task_assignments_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: workspaces id; Type: DEFAULT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.workspaces ALTER COLUMN id SET DEFAULT nextval('public.workspaces_id_seq'::regclass);


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.activity_logs (id, user_id, event_type, entity_type, entity_id, title, event_at, operation_id, payload, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: adaptive_context; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.adaptive_context (id, user_id, task_id, energy_level, stress_level, task_difficulty, skill_familiarity, interruption_count, context_switch_cost, focus_duration_minutes, checked_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_proposals; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.ai_proposals (id, user_id, proposal_type, schema_version, payload, validation_result, decision, operation_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_provider_configs; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.ai_provider_configs (id, provider, model, base_url, api_key, enabled, created_at, updated_at, user_id, protocol, credential_hint, last_verified_at, last_status, last_error_code) FROM stdin;
\.


--
-- Data for Name: ai_runs; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.ai_runs (id, user_id, provider, model, proposal_type, schema_version, prompt_template_version, context_hash, input_tokens, output_tokens, status, latency_ms, error_code, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.attachments (id, user_id, task_id, filename, stored_name, disk, mime_type, size_bytes, sha256, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: boost_targets; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.boost_targets (id, user_id, break_period_id, start_date, end_date, target_percent, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: break_periods; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.break_periods (id, user_id, start_date, end_date, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cache; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.cache (key, value, expiration) FROM stdin;
\.


--
-- Data for Name: cache_locks; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.cache_locks (key, owner, expiration) FROM stdin;
\.


--
-- Data for Name: canvas_documents; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.canvas_documents (id, canvas_id, schema_version, scene_json, version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: canvas_files; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.canvas_files (id, canvas_id, storage_path, content_type, size_bytes, sha256, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: canvases; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.canvases (id, user_id, title, goal_id, milestone_id, program_id, task_id, version, created_at, updated_at, archived_at, workspace_id) FROM stdin;
\.


--
-- Data for Name: execution_sessions; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.execution_sessions (id, user_id, task_id, status, started_at, last_resumed_at, accumulated_seconds, ended_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: focus_sessions; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.focus_sessions (id, user_id, task_id, started_at, ended_at, duration_minutes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: goals; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.goals (id, user_id, title, description, horizon, start_date, target_date, target_metric, status, priority_tier, progress_mode, progress, created_at, updated_at, workspace_id) FROM stdin;
\.


--
-- Data for Name: hard_landscape_events; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.hard_landscape_events (id, user_id, title, type, start_at, end_at, recurrence, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: imports; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.imports (id, user_id, type, filename, status, confidence, rows, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.job_batches (id, name, total_jobs, pending_jobs, failed_jobs, failed_job_ids, options, cancelled_at, created_at, finished_at) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.jobs (id, queue, payload, attempts, reserved_at, available_at, created_at) FROM stdin;
\.


--
-- Data for Name: knowledge_links; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.knowledge_links (id, user_id, source_type, source_id, target_type, target_id, link_type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	0001_01_01_000000_create_users_table	1
2	0001_01_01_000001_create_cache_table	1
3	0001_01_01_000002_create_jobs_table	1
4	2026_08_17_135230_create_personal_access_tokens_table	1
5	2026_08_17_135300_create_profiles_table	1
6	2026_08_17_150000_create_goals_table	1
7	2026_08_17_160000_create_milestones_table	1
8	2026_08_17_170000_create_programs_table	1
9	2026_08_17_180000_create_tasks_and_subtasks_table	1
10	2026_08_17_190000_create_activity_logs_table	1
11	2026_08_18_000000_create_notes_table	1
12	2026_08_18_000001_add_notes_search_vector	1
13	2026_08_18_010000_create_knowledge_links_table	1
14	2026_08_18_100000_create_canvases_table	1
15	2026_08_18_100001_create_canvas_documents_table	1
16	2026_08_18_100002_create_canvas_files_table	1
17	2026_08_18_120000_create_notifications_table	1
18	2026_08_18_130000_create_adaptive_context_table	1
19	2026_08_18_140000_create_focus_sessions_table	1
20	2026_08_18_150000_create_progress_events_table	1
21	2026_08_18_160000_create_ai_audit_tables	1
22	2026_08_19_100000_create_scheduler_runs_table	1
23	2026_08_19_110000_create_task_assignments_table	1
24	2026_08_19_120000_create_hard_landscape_events_table	1
25	2026_08_19_130000_create_schedule_overrides_table	1
26	2026_08_19_140000_add_archived_at_to_canvases_table	1
27	2026_08_19_150000_create_execution_sessions_table	1
28	2026_08_20_150000_create_recharge_sessions_table	1
29	2026_08_20_170000_create_pause_events_table	1
30	2026_08_20_180000_create_break_periods_table	1
31	2026_08_20_190000_create_boost_targets_table	1
32	2026_08_20_200000_create_attachments_table	1
33	2026_08_20_210000_create_imports_table	1
34	2026_08_22_000000_create_ai_provider_configs_table	1
35	2026_08_25_000001_extend_ai_provider_configs_control_plane	1
36	2026_08_26_000001_create_workspaces_and_scope	1
\.


--
-- Data for Name: milestones; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.milestones (id, user_id, goal_id, title, description, sequence, target_date, estimated_minutes, status, progress_mode, progress, completed_at, version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.notes (id, user_id, title, document_json, markdown_cache, plain_text_cache, version, created_at, updated_at, search_vector, workspace_id) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.notifications (id, user_id, type, scheduled_for, title, payload, read_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: pause_events; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.pause_events (id, user_id, type, week_start, week_end, keep_task_ids, moved_task_ids, conflict_task_ids, schedule_version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.profiles (id, user_id, display_name, locale, timezone, week_start_day, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: programs; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.programs (id, user_id, name, description, category, workload_type, weekly_target_minutes, min_weekly_minutes, max_weekly_minutes, status, priority_tier, version, created_at, updated_at, workspace_id) FROM stdin;
\.


--
-- Data for Name: progress_events; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.progress_events (id, user_id, event_type, entity_type, entity_id, title, occurred_at, operation_id, payload, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: recharge_sessions; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.recharge_sessions (id, user_id, status, started_at, last_resumed_at, accumulated_seconds, duration_minutes, ended_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: schedule_overrides; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.schedule_overrides (id, user_id, hard_landscape_event_id, type, effective_from, effective_to, override_start_at, override_end_at, reason, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: scheduler_runs; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.scheduler_runs (id, user_id, job, status, duration_ms, error, started_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
\.


--
-- Data for Name: subtasks; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.subtasks (id, user_id, task_id, title, notes, sequence, completed, version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_assignments; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.task_assignments (id, user_id, task_id, date, start_at, end_at, duration_minutes, status, source, schedule_version, locked, version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.tasks (id, user_id, program_id, goal_id, milestone_id, title, description, status, priority_tier, estimated_minutes, due_at, progress_mode, progress, version, created_at, updated_at, workspace_id) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.users (id, name, email, email_verified_at, password, remember_token, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: workspaces; Type: TABLE DATA; Schema: public; Owner: kinevo
--

COPY public.workspaces (id, user_id, name, slug, description, icon, accent, type, is_default, status, created_at, updated_at) FROM stdin;
\.


--
-- Name: activity_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.activity_logs_id_seq', 48, true);


--
-- Name: adaptive_context_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.adaptive_context_id_seq', 7, true);


--
-- Name: ai_proposals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.ai_proposals_id_seq', 26, true);


--
-- Name: ai_provider_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.ai_provider_configs_id_seq', 10, true);


--
-- Name: ai_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.ai_runs_id_seq', 32, true);


--
-- Name: attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.attachments_id_seq', 7, true);


--
-- Name: boost_targets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.boost_targets_id_seq', 6, true);


--
-- Name: break_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.break_periods_id_seq', 15, true);


--
-- Name: canvas_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.canvas_documents_id_seq', 4, true);


--
-- Name: canvas_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.canvas_files_id_seq', 3, true);


--
-- Name: canvases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.canvases_id_seq', 38, true);


--
-- Name: execution_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.execution_sessions_id_seq', 6, true);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, true);


--
-- Name: focus_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.focus_sessions_id_seq', 27, true);


--
-- Name: goals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.goals_id_seq', 74, true);


--
-- Name: hard_landscape_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.hard_landscape_events_id_seq', 28, true);


--
-- Name: imports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.imports_id_seq', 15, true);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.jobs_id_seq', 1, true);


--
-- Name: knowledge_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.knowledge_links_id_seq', 18, true);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.migrations_id_seq', 36, true);


--
-- Name: milestones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.milestones_id_seq', 22, true);


--
-- Name: notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.notes_id_seq', 50, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.notifications_id_seq', 6, true);


--
-- Name: pause_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.pause_events_id_seq', 2, true);


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.personal_access_tokens_id_seq', 372, true);


--
-- Name: profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.profiles_id_seq', 4, true);


--
-- Name: programs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.programs_id_seq', 18, true);


--
-- Name: progress_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.progress_events_id_seq', 20, true);


--
-- Name: recharge_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.recharge_sessions_id_seq', 13, true);


--
-- Name: schedule_overrides_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.schedule_overrides_id_seq', 5, true);


--
-- Name: scheduler_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.scheduler_runs_id_seq', 2, true);


--
-- Name: subtasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.subtasks_id_seq', 16, true);


--
-- Name: task_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.task_assignments_id_seq', 36, true);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.tasks_id_seq', 117, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.users_id_seq', 438, true);


--
-- Name: workspaces_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kinevo
--

SELECT pg_catalog.setval('public.workspaces_id_seq', 40, true);


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: activity_logs activity_logs_user_id_operation_id_unique; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_user_id_operation_id_unique UNIQUE (user_id, operation_id);


--
-- Name: adaptive_context adaptive_context_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.adaptive_context
    ADD CONSTRAINT adaptive_context_pkey PRIMARY KEY (id);


--
-- Name: ai_proposals ai_proposals_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.ai_proposals
    ADD CONSTRAINT ai_proposals_pkey PRIMARY KEY (id);


--
-- Name: ai_provider_configs ai_provider_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.ai_provider_configs
    ADD CONSTRAINT ai_provider_configs_pkey PRIMARY KEY (id);


--
-- Name: ai_runs ai_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.ai_runs
    ADD CONSTRAINT ai_runs_pkey PRIMARY KEY (id);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: attachments attachments_stored_name_unique; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_stored_name_unique UNIQUE (stored_name);


--
-- Name: boost_targets boost_targets_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.boost_targets
    ADD CONSTRAINT boost_targets_pkey PRIMARY KEY (id);


--
-- Name: break_periods break_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.break_periods
    ADD CONSTRAINT break_periods_pkey PRIMARY KEY (id);


--
-- Name: cache_locks cache_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.cache_locks
    ADD CONSTRAINT cache_locks_pkey PRIMARY KEY (key);


--
-- Name: cache cache_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.cache
    ADD CONSTRAINT cache_pkey PRIMARY KEY (key);


--
-- Name: canvas_documents canvas_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.canvas_documents
    ADD CONSTRAINT canvas_documents_pkey PRIMARY KEY (id);


--
-- Name: canvas_files canvas_files_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.canvas_files
    ADD CONSTRAINT canvas_files_pkey PRIMARY KEY (id);


--
-- Name: canvases canvases_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.canvases
    ADD CONSTRAINT canvases_pkey PRIMARY KEY (id);


--
-- Name: execution_sessions execution_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.execution_sessions
    ADD CONSTRAINT execution_sessions_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: focus_sessions focus_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.focus_sessions
    ADD CONSTRAINT focus_sessions_pkey PRIMARY KEY (id);


--
-- Name: goals goals_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_pkey PRIMARY KEY (id);


--
-- Name: hard_landscape_events hard_landscape_events_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.hard_landscape_events
    ADD CONSTRAINT hard_landscape_events_pkey PRIMARY KEY (id);


--
-- Name: imports imports_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.imports
    ADD CONSTRAINT imports_pkey PRIMARY KEY (id);


--
-- Name: job_batches job_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.job_batches
    ADD CONSTRAINT job_batches_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: knowledge_links knowledge_links_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.knowledge_links
    ADD CONSTRAINT knowledge_links_pkey PRIMARY KEY (id);


--
-- Name: knowledge_links knowledge_links_source_target_link_unique; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.knowledge_links
    ADD CONSTRAINT knowledge_links_source_target_link_unique UNIQUE (user_id, source_type, source_id, target_type, target_id, link_type);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: milestones milestones_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.milestones
    ADD CONSTRAINT milestones_pkey PRIMARY KEY (id);


--
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_user_id_type_scheduled_for_unique; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_type_scheduled_for_unique UNIQUE (user_id, type, scheduled_for);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: pause_events pause_events_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.pause_events
    ADD CONSTRAINT pause_events_pkey PRIMARY KEY (id);


--
-- Name: pause_events pause_events_user_id_type_week_start_unique; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.pause_events
    ADD CONSTRAINT pause_events_user_id_type_week_start_unique UNIQUE (user_id, type, week_start);


--
-- Name: personal_access_tokens personal_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_token_unique UNIQUE (token);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_user_id_unique UNIQUE (user_id);


--
-- Name: programs programs_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.programs
    ADD CONSTRAINT programs_pkey PRIMARY KEY (id);


--
-- Name: progress_events progress_events_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.progress_events
    ADD CONSTRAINT progress_events_pkey PRIMARY KEY (id);


--
-- Name: progress_events progress_events_user_id_operation_id_unique; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.progress_events
    ADD CONSTRAINT progress_events_user_id_operation_id_unique UNIQUE (user_id, operation_id);


--
-- Name: recharge_sessions recharge_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.recharge_sessions
    ADD CONSTRAINT recharge_sessions_pkey PRIMARY KEY (id);


--
-- Name: schedule_overrides schedule_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.schedule_overrides
    ADD CONSTRAINT schedule_overrides_pkey PRIMARY KEY (id);


--
-- Name: scheduler_runs scheduler_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.scheduler_runs
    ADD CONSTRAINT scheduler_runs_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: subtasks subtasks_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.subtasks
    ADD CONSTRAINT subtasks_pkey PRIMARY KEY (id);


--
-- Name: task_assignments task_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.task_assignments
    ADD CONSTRAINT task_assignments_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: workspaces workspaces_pkey; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_pkey PRIMARY KEY (id);


--
-- Name: workspaces workspaces_user_id_slug_unique; Type: CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_user_id_slug_unique UNIQUE (user_id, slug);


--
-- Name: activity_logs_user_id_event_at_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX activity_logs_user_id_event_at_index ON public.activity_logs USING btree (user_id, event_at);


--
-- Name: adaptive_context_user_id_checked_at_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX adaptive_context_user_id_checked_at_index ON public.adaptive_context USING btree (user_id, checked_at);


--
-- Name: adaptive_context_user_id_task_id_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX adaptive_context_user_id_task_id_index ON public.adaptive_context USING btree (user_id, task_id);


--
-- Name: ai_proposals_user_id_created_at_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX ai_proposals_user_id_created_at_index ON public.ai_proposals USING btree (user_id, created_at);


--
-- Name: ai_proposals_user_id_decision_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX ai_proposals_user_id_decision_index ON public.ai_proposals USING btree (user_id, decision);


--
-- Name: ai_provider_configs_user_id_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX ai_provider_configs_user_id_index ON public.ai_provider_configs USING btree (user_id);


--
-- Name: ai_runs_user_id_created_at_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX ai_runs_user_id_created_at_index ON public.ai_runs USING btree (user_id, created_at);


--
-- Name: ai_runs_user_id_proposal_type_created_at_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX ai_runs_user_id_proposal_type_created_at_index ON public.ai_runs USING btree (user_id, proposal_type, created_at);


--
-- Name: attachments_task_id_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX attachments_task_id_index ON public.attachments USING btree (task_id);


--
-- Name: attachments_user_id_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX attachments_user_id_index ON public.attachments USING btree (user_id);


--
-- Name: boost_targets_user_id_status_end_date_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX boost_targets_user_id_status_end_date_index ON public.boost_targets USING btree (user_id, status, end_date);


--
-- Name: break_periods_user_id_status_end_date_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX break_periods_user_id_status_end_date_index ON public.break_periods USING btree (user_id, status, end_date);


--
-- Name: cache_expiration_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX cache_expiration_index ON public.cache USING btree (expiration);


--
-- Name: cache_locks_expiration_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX cache_locks_expiration_index ON public.cache_locks USING btree (expiration);


--
-- Name: canvas_documents_canvas_id_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX canvas_documents_canvas_id_index ON public.canvas_documents USING btree (canvas_id);


--
-- Name: canvas_files_canvas_id_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX canvas_files_canvas_id_index ON public.canvas_files USING btree (canvas_id);


--
-- Name: canvases_user_id_goal_id_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX canvases_user_id_goal_id_index ON public.canvases USING btree (user_id, goal_id);


--
-- Name: canvases_user_id_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX canvases_user_id_index ON public.canvases USING btree (user_id);


--
-- Name: canvases_user_id_task_id_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX canvases_user_id_task_id_index ON public.canvases USING btree (user_id, task_id);


--
-- Name: canvases_workspace_id_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX canvases_workspace_id_index ON public.canvases USING btree (workspace_id);


--
-- Name: execution_sessions_user_id_status_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX execution_sessions_user_id_status_index ON public.execution_sessions USING btree (user_id, status);


--
-- Name: execution_sessions_user_id_task_id_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX execution_sessions_user_id_task_id_index ON public.execution_sessions USING btree (user_id, task_id);


--
-- Name: failed_jobs_connection_queue_failed_at_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX failed_jobs_connection_queue_failed_at_index ON public.failed_jobs USING btree (connection, queue, failed_at);


--
-- Name: focus_sessions_user_id_started_at_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX focus_sessions_user_id_started_at_index ON public.focus_sessions USING btree (user_id, started_at);


--
-- Name: focus_sessions_user_id_task_id_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX focus_sessions_user_id_task_id_index ON public.focus_sessions USING btree (user_id, task_id);


--
-- Name: goals_user_id_status_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX goals_user_id_status_index ON public.goals USING btree (user_id, status);


--
-- Name: goals_workspace_id_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX goals_workspace_id_index ON public.goals USING btree (workspace_id);


--
-- Name: hard_landscape_events_user_id_start_at_end_at_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX hard_landscape_events_user_id_start_at_end_at_index ON public.hard_landscape_events USING btree (user_id, start_at, end_at);


--
-- Name: imports_user_id_status_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX imports_user_id_status_index ON public.imports USING btree (user_id, status);


--
-- Name: jobs_queue_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX jobs_queue_index ON public.jobs USING btree (queue);


--
-- Name: knowledge_links_user_id_source_type_source_id_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX knowledge_links_user_id_source_type_source_id_index ON public.knowledge_links USING btree (user_id, source_type, source_id);


--
-- Name: knowledge_links_user_id_target_type_target_id_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX knowledge_links_user_id_target_type_target_id_index ON public.knowledge_links USING btree (user_id, target_type, target_id);


--
-- Name: milestones_goal_id_sequence_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX milestones_goal_id_sequence_index ON public.milestones USING btree (goal_id, sequence);


--
-- Name: milestones_user_id_status_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX milestones_user_id_status_index ON public.milestones USING btree (user_id, status);


--
-- Name: notes_search_idx; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX notes_search_idx ON public.notes USING gin (search_vector);


--
-- Name: notes_user_id_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX notes_user_id_index ON public.notes USING btree (user_id);


--
-- Name: notes_workspace_id_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX notes_workspace_id_index ON public.notes USING btree (workspace_id);


--
-- Name: notifications_user_id_scheduled_for_read_at_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX notifications_user_id_scheduled_for_read_at_index ON public.notifications USING btree (user_id, scheduled_for, read_at);


--
-- Name: pause_events_user_id_week_start_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX pause_events_user_id_week_start_index ON public.pause_events USING btree (user_id, week_start);


--
-- Name: personal_access_tokens_expires_at_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX personal_access_tokens_expires_at_index ON public.personal_access_tokens USING btree (expires_at);


--
-- Name: personal_access_tokens_tokenable_type_tokenable_id_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX personal_access_tokens_tokenable_type_tokenable_id_index ON public.personal_access_tokens USING btree (tokenable_type, tokenable_id);


--
-- Name: programs_user_id_status_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX programs_user_id_status_index ON public.programs USING btree (user_id, status);


--
-- Name: programs_workspace_id_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX programs_workspace_id_index ON public.programs USING btree (workspace_id);


--
-- Name: progress_events_user_id_occurred_at_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX progress_events_user_id_occurred_at_index ON public.progress_events USING btree (user_id, occurred_at);


--
-- Name: recharge_sessions_user_id_started_at_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX recharge_sessions_user_id_started_at_index ON public.recharge_sessions USING btree (user_id, started_at);


--
-- Name: recharge_sessions_user_id_status_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX recharge_sessions_user_id_status_index ON public.recharge_sessions USING btree (user_id, status);


--
-- Name: schedule_overrides_user_id_effective_from_effective_to_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX schedule_overrides_user_id_effective_from_effective_to_index ON public.schedule_overrides USING btree (user_id, effective_from, effective_to);


--
-- Name: schedule_overrides_user_id_hard_landscape_event_id_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX schedule_overrides_user_id_hard_landscape_event_id_index ON public.schedule_overrides USING btree (user_id, hard_landscape_event_id);


--
-- Name: scheduler_runs_status_started_at_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX scheduler_runs_status_started_at_index ON public.scheduler_runs USING btree (status, started_at);


--
-- Name: scheduler_runs_user_id_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX scheduler_runs_user_id_index ON public.scheduler_runs USING btree (user_id);


--
-- Name: scheduler_runs_user_id_started_at_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX scheduler_runs_user_id_started_at_index ON public.scheduler_runs USING btree (user_id, started_at);


--
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- Name: subtasks_task_id_sequence_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX subtasks_task_id_sequence_index ON public.subtasks USING btree (task_id, sequence);


--
-- Name: task_assignments_task_id_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX task_assignments_task_id_index ON public.task_assignments USING btree (task_id);


--
-- Name: task_assignments_user_id_date_start_at_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX task_assignments_user_id_date_start_at_index ON public.task_assignments USING btree (user_id, date, start_at);


--
-- Name: task_assignments_user_id_start_at_end_at_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX task_assignments_user_id_start_at_end_at_index ON public.task_assignments USING btree (user_id, start_at, end_at);


--
-- Name: tasks_user_id_program_id_status_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX tasks_user_id_program_id_status_index ON public.tasks USING btree (user_id, program_id, status);


--
-- Name: tasks_user_id_status_due_at_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX tasks_user_id_status_due_at_index ON public.tasks USING btree (user_id, status, due_at);


--
-- Name: tasks_workspace_id_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX tasks_workspace_id_index ON public.tasks USING btree (workspace_id);


--
-- Name: workspaces_status_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX workspaces_status_index ON public.workspaces USING btree (status);


--
-- Name: workspaces_type_index; Type: INDEX; Schema: public; Owner: kinevo
--

CREATE INDEX workspaces_type_index ON public.workspaces USING btree (type);


--
-- Name: notes notes_search_update; Type: TRIGGER; Schema: public; Owner: kinevo
--

CREATE TRIGGER notes_search_update BEFORE INSERT OR UPDATE ON public.notes FOR EACH ROW EXECUTE FUNCTION public.notes_search_trigger();


--
-- Name: activity_logs activity_logs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: adaptive_context adaptive_context_task_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.adaptive_context
    ADD CONSTRAINT adaptive_context_task_id_foreign FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: adaptive_context adaptive_context_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.adaptive_context
    ADD CONSTRAINT adaptive_context_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_proposals ai_proposals_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.ai_proposals
    ADD CONSTRAINT ai_proposals_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_runs ai_runs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.ai_runs
    ADD CONSTRAINT ai_runs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: attachments attachments_task_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_task_id_foreign FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: attachments attachments_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: boost_targets boost_targets_break_period_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.boost_targets
    ADD CONSTRAINT boost_targets_break_period_id_foreign FOREIGN KEY (break_period_id) REFERENCES public.break_periods(id) ON DELETE SET NULL;


--
-- Name: boost_targets boost_targets_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.boost_targets
    ADD CONSTRAINT boost_targets_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: break_periods break_periods_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.break_periods
    ADD CONSTRAINT break_periods_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: canvas_documents canvas_documents_canvas_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.canvas_documents
    ADD CONSTRAINT canvas_documents_canvas_id_foreign FOREIGN KEY (canvas_id) REFERENCES public.canvases(id) ON DELETE CASCADE;


--
-- Name: canvas_files canvas_files_canvas_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.canvas_files
    ADD CONSTRAINT canvas_files_canvas_id_foreign FOREIGN KEY (canvas_id) REFERENCES public.canvases(id) ON DELETE CASCADE;


--
-- Name: canvases canvases_goal_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.canvases
    ADD CONSTRAINT canvases_goal_id_foreign FOREIGN KEY (goal_id) REFERENCES public.goals(id) ON DELETE SET NULL;


--
-- Name: canvases canvases_milestone_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.canvases
    ADD CONSTRAINT canvases_milestone_id_foreign FOREIGN KEY (milestone_id) REFERENCES public.milestones(id) ON DELETE SET NULL;


--
-- Name: canvases canvases_program_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.canvases
    ADD CONSTRAINT canvases_program_id_foreign FOREIGN KEY (program_id) REFERENCES public.programs(id) ON DELETE SET NULL;


--
-- Name: canvases canvases_task_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.canvases
    ADD CONSTRAINT canvases_task_id_foreign FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: canvases canvases_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.canvases
    ADD CONSTRAINT canvases_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: execution_sessions execution_sessions_task_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.execution_sessions
    ADD CONSTRAINT execution_sessions_task_id_foreign FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: execution_sessions execution_sessions_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.execution_sessions
    ADD CONSTRAINT execution_sessions_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: focus_sessions focus_sessions_task_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.focus_sessions
    ADD CONSTRAINT focus_sessions_task_id_foreign FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: focus_sessions focus_sessions_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.focus_sessions
    ADD CONSTRAINT focus_sessions_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: goals goals_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: hard_landscape_events hard_landscape_events_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.hard_landscape_events
    ADD CONSTRAINT hard_landscape_events_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: imports imports_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.imports
    ADD CONSTRAINT imports_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: knowledge_links knowledge_links_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.knowledge_links
    ADD CONSTRAINT knowledge_links_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: milestones milestones_goal_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.milestones
    ADD CONSTRAINT milestones_goal_id_foreign FOREIGN KEY (goal_id) REFERENCES public.goals(id) ON DELETE CASCADE;


--
-- Name: milestones milestones_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.milestones
    ADD CONSTRAINT milestones_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notes notes_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: pause_events pause_events_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.pause_events
    ADD CONSTRAINT pause_events_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: profiles profiles_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: programs programs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.programs
    ADD CONSTRAINT programs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: progress_events progress_events_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.progress_events
    ADD CONSTRAINT progress_events_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: recharge_sessions recharge_sessions_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.recharge_sessions
    ADD CONSTRAINT recharge_sessions_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: schedule_overrides schedule_overrides_hard_landscape_event_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.schedule_overrides
    ADD CONSTRAINT schedule_overrides_hard_landscape_event_id_foreign FOREIGN KEY (hard_landscape_event_id) REFERENCES public.hard_landscape_events(id) ON DELETE CASCADE;


--
-- Name: schedule_overrides schedule_overrides_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.schedule_overrides
    ADD CONSTRAINT schedule_overrides_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: subtasks subtasks_task_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.subtasks
    ADD CONSTRAINT subtasks_task_id_foreign FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: subtasks subtasks_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.subtasks
    ADD CONSTRAINT subtasks_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: task_assignments task_assignments_task_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.task_assignments
    ADD CONSTRAINT task_assignments_task_id_foreign FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_assignments task_assignments_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.task_assignments
    ADD CONSTRAINT task_assignments_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_goal_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_goal_id_foreign FOREIGN KEY (goal_id) REFERENCES public.goals(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_milestone_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_milestone_id_foreign FOREIGN KEY (milestone_id) REFERENCES public.milestones(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_program_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_program_id_foreign FOREIGN KEY (program_id) REFERENCES public.programs(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: workspaces workspaces_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: kinevo
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict yeet7BX3hvARiL1kAzhzlvXb0m2ZrnWUqy51fTSGITa37c23xiZt54MEXjb00vF

